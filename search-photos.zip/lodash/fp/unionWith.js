var convert = require('./convert'),
    func = convert('unionWith', require('../unionWith'));

func.placeholder = require('./placeholder');
module.exports = func;
