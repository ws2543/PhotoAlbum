var convert = require('./convert'),
    func = convert('compact', require('../compact'), require('./_falseOptions'));

func.placeholder = require('./placeholder');
module.exports = func;
