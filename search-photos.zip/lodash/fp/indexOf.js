var convert = require('./convert'),
    func = convert('indexOf', require('../indexOf'));

func.placeholder = require('./placeholder');
module.exports = func;
