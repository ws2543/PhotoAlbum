var convert = require('./convert'),
    func = convert('isNull', require('../isNull'), require('./_falseOptions'));

func.placeholder = require('./placeholder');
module.exports = func;
