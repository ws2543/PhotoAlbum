var convert = require('./convert'),
    func = convert('union', require('../union'));

func.placeholder = require('./placeholder');
module.exports = func;
